<?php
include 'db_connect.php';

// Fetch clans from the database
$stmt = $pdo->query("SELECT * FROM clans");
$clans = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($clans as $clan) {
    echo "<div class='clan'>";
    echo "<h3>" . htmlspecialchars($clan['name']) . "</h3>";
    echo "<p>" . htmlspecialchars($clan['description']) . "</p>";
    echo "<form action='join_clan.php' method='POST'>";
    echo "<input type='hidden' name='clan_id' value='" . $clan['id'] . "'>";
    echo "<button type='submit'>Join Clan</button>";
    echo "</form>";
    echo "</div>";
}
?>
