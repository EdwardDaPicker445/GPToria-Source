<?php
session_start();
require 'db.php'; // Ensure this file connects to your database

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$thread_id = $_GET['id'] ?? null;

// Fetch thread details
$thread_query = $pdo->prepare("
    SELECT forum_topics.id, forum_topics.title, forum_topics.created_at, forum_categories.name AS category_name, users.username
    FROM forum_topics
    JOIN forum_categories ON forum_topics.category_id = forum_categories.id
    JOIN users ON forum_topics.created_by = users.id
    WHERE forum_topics.id = ?
");
$thread_query->execute([$thread_id]);
$thread = $thread_query->fetch(PDO::FETCH_ASSOC);

// Fetch posts for the thread
$posts_query = $pdo->prepare("
    SELECT forum_posts.content, forum_posts.created_at, users.username
    FROM forum_posts
    JOIN users ON forum_posts.user_id = users.id
    WHERE forum_posts.topic_id = ?
    ORDER BY forum_posts.created_at ASC
");
$posts_query->execute([$thread_id]);
$posts = $posts_query->fetchAll(PDO::FETCH_ASSOC);

// Handle new post submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content = $_POST['content'];
    $user_id = $_SESSION['user_id'];

    $stmt = $pdo->prepare("INSERT INTO forum_posts (topic_id, user_id, content) VALUES (?, ?, ?)");
    $stmt->execute([$thread_id, $user_id, $content]);

    header("Location: thread.php?id=" . $thread_id);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($thread['title']); ?></title>
    <link rel="stylesheet" href="forum.css"> <!-- Make sure this file styles your forum page -->
</head>
<body>
    <header>
        <div class="top-bar">
            <a href="index.php">Home</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
        </div>
        <div class="second-navbar">
            <a href="home.php">Home</a>
            <a href="settings.php">Settings</a>
            <a href="avatar.php">Avatar</a>
            <a href="profile.php">Profile</a>
            <a href="download.php">Download</a>
            <a href="trades.php">Trades</a>
            <a href="sets.php">Sets</a>
            <a href="currency.php">Currency</a>
            <a href="blog.php">Blog</a>
        </div>
    </header>

    <main>
        <h1><?php echo htmlspecialchars($thread['title']); ?></h1>
        <p>Category: <?php echo htmlspecialchars($thread['category_name']); ?></p>
        <p>Created by: <?php echo htmlspecialchars($thread['username']); ?></p>
        <p>Posted on: <?php echo htmlspecialchars($thread['created_at']); ?></p>

        <section class="thread-posts">
            <?php foreach ($posts as $post): ?>
                <div class="post">
                    <p><strong><?php echo htmlspecialchars($post['username']); ?></strong> said:</p>
                    <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                    <p><em>Posted on: <?php echo htmlspecialchars($post['created_at']); ?></em></p>
                </div>
            <?php endforeach; ?>
        </section>

        <section class="post-form">
            <h2>Reply to Thread</h2>
            <form action="thread.php?id=<?php echo $thread_id; ?>" method="post">
                <label for="content">Your Reply:</label>
                <textarea id="content" name="content" rows="5" required></textarea>
                <button type="submit">Post Reply</button>
            </form>
        </section>
    </main>
</body>
</html>
