<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user information from the database
$stmt = $pdo->prepare("SELECT username, avatar, bio, status FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "User not found.";
    exit();
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <header class="top-bar">
        <nav class="navbar">
            <a href="index.php">Home</a>
            <a href="shop.php">Shop</a>
            <a href="clans.php">Clans</a>
            <a href="users.php">Users</a>
            <a href="forum.php">Forum</a>
            <a href="membership.php">Membership</a>
        </nav>
        <div class="user-menu">
            <a href="profile.php"><img src="/avatars/<?php echo htmlspecialchars($user['avatar']); ?>" alt="User Avatar" class="avatar-icon"></a>
            <a href="dashboard.php?logout=true" class="logout-button">Logout</a>
        </div>
    </header>
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h1>
        <div class="user-info">
            <img src="/avatars/<?php echo htmlspecialchars($user['avatar']); ?>" alt="User Avatar" class="user-avatar">
            <div class="user-details">
                <p><strong>Bio:</strong> <?php echo htmlspecialchars($user['bio']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($user['status']); ?></p>
            </div>
        </div>
    </div>
</body>
</html>
