<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$clan_id = $_POST['clan_id'] ?? null;

if ($clan_id) {
    try {
        // Check if the user is already a member of the clan
        $stmt = $pdo->prepare("SELECT * FROM clan_members WHERE user_id = ? AND clan_id = ?");
        $stmt->execute([$user_id, $clan_id]);
        $is_member = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$is_member) {
            // Add user to the clan
            $stmt = $pdo->prepare("INSERT INTO clan_members (user_id, clan_id) VALUES (?, ?)");
            $stmt->execute([$user_id, $clan_id]);

            // Update clan members count
            $stmt = $pdo->prepare("UPDATE clans SET members = members + 1 WHERE id = ?");
            $stmt->execute([$clan_id]);

            header("Location: clan_details.php?id=$clan_id");
        } else {
            echo "You are already a member of this clan.";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Invalid clan ID.";
}
?>
