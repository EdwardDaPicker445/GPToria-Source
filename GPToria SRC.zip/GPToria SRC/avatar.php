<?php
session_start();
include 'db_connect.php'; // Ensure you include your database connection

// Fetch user ID from session
$user_id = $_SESSION['user_id'];

// Update user avatar in database
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['avatar'])) {
        $selected_avatar = intval($_POST['avatar']);
        if ($selected_avatar >= 1 && $selected_avatar <= 7) {
            $stmt = $pdo->prepare("UPDATE users SET avatar = :avatar WHERE id = :id");
            $stmt->execute(['avatar' => $selected_avatar . '.png', 'id' => $user_id]);
            $message = "Avatar updated successfully!";
        } else {
            $message = "Invalid avatar selection.";
        }
    }
}

// Fetch the current avatar
$stmt = $pdo->prepare("SELECT avatar FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch();
$current_avatar = $user['avatar'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Avatar</title>
    <link rel="stylesheet" href="avatar.css">
</head>
<body>
    <header>
        <h1>Choose Your Avatar</h1>
    </header>
    <main>
        <?php if (isset($message)) : ?>
            <p><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="avatar-gallery">
                <?php for ($i = 1; $i <= 7; $i++) : ?>
                    <div class="avatar-option">
                        <input type="radio" id="avatar<?php echo $i; ?>" name="avatar" value="<?php echo $i; ?>" <?php if ($current_avatar == $i . '.png') echo 'checked'; ?>>
                        <label for="avatar<?php echo $i; ?>">
                            <img src="/avatars/<?php echo $i; ?>.png" alt="Avatar <?php echo $i; ?>">
                        </label>
                    </div>
                <?php endfor; ?>
            </div>
            <button type="submit">Save Avatar</button>
        </form>
    </main>
</body>
</html>
