<?php
$dsn = 'mysql:host=mysql3.serv00.com;dbname=m5499_projex;charset=utf8';
$username = 'm5499_brickdata';
$password = '9i/WEetDo8MUsH-g6364a4^4BZl5P[';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
