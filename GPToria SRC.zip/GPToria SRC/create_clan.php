<?php
session_start();
include 'db_connect.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $user_id = $_SESSION['user_id']; // Assuming user ID is stored in session

    // Validate input
    if (empty($name)) {
        echo "Clan name is required";
        exit();
    }

    // Insert clan into the database
    $stmt = $pdo->prepare("INSERT INTO clans (name, description) VALUES (?, ?)");
    if ($stmt->execute([$name, $description])) {
        $clan_id = $pdo->lastInsertId();

        // Add the creator as the first member
        $stmt = $pdo->prepare("INSERT INTO clan_members (clan_id, user_id) VALUES (?, ?)");
        $stmt->execute([$clan_id, $user_id]);

        echo "Clan created successfully!";
    } else {
        echo "Error creating clan.";
    }
}
?>
