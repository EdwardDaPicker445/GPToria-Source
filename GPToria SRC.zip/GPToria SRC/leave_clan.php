<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$clan_id = $_POST['clan_id'] ?? null;

if ($clan_id) {
    try {
        // Remove user from the clan
        $stmt = $pdo->prepare("DELETE FROM clan_members WHERE user_id = ? AND clan_id = ?");
        $stmt->execute([$user_id, $clan_id]);

        // Update clan members count
        $stmt = $pdo->prepare("UPDATE clans SET members = members - 1 WHERE id = ?");
        $stmt->execute([$clan_id]);

        header("Location: clan_details.php?id=$clan_id");
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    echo "Invalid clan ID.";
}
?>
