<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - GPToria</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap">
    <link rel="stylesheet" href="shop.css">
</head>
<body>
    <header>
        <!-- Include navbars here -->
        <a href="logout.php" id="logoutButton">Logout</a>
        <!-- Main Navbar -->
        <nav id="mainNavbar">
            <a href="play.php">Play</a>
            <a href="shop.php">Shop</a>
            <a href="clans.php">Clans</a>
            <a href="users.php">Users</a>
            <a href="forum.php">Forum</a>
            <a href="membership.php">Membership</a>
        </nav>
        <!-- Dropdown Navbar -->
        <div id="dropdownNavbar">
            <button id="dropdownButton">More Options &#9662;</button>
            <div id="dropdownMenu">
                <a href="home.php">Home</a>
                <a href="settings.php">Settings</a>
                <a href="avatar.php">Avatar</a>
                <a href="profile.php">Profile</a>
                <a href="download.php">Download</a>
                <a href="trades.php">Trades</a>
                <a href="sets.php">Sets</a>
                <a href="currency.php">Currency</a>
                <a href="blog.php">Blog</a>
            </div>
        </div>
    </header>
    <main>
        <section id="shop">
            <aside id="sidebar">
                <h2>Avatar Store</h2>
                <input type="text" id="searchBar" placeholder="Search...">
                <div class="filter-section">
                    <a href="create.php" class="filter-btn">Create</a>
                    <a href="wardrobe.php" class="filter-btn">Wardrobe</a>
                    <h3>FILTER</h3>
                    <label><input type="checkbox" id="showUnavailable"> Show unavailable items</label>
                    <label><input type="checkbox" id="specialItems"> Special items only</label>
                    <label><input type="checkbox" id="eventItems"> Event items only</label>
                    <div class="price-section">
                        <h3>Price</h3>
                        <input type="range" id="priceRange" min="0" max="1000" step="10" value="0">
                        <span id="priceLabel">0 bucks</span>
                    </div>
                    <h3>Categories</h3>
                    <label><input type="radio" name="category" value="all" checked> All</label>
                    <label><input type="radio" name="category" value="accessories"> Accessories</label>
                    <label><input type="radio" name="category" value="clothing"> Clothing</label>
                    <label><input type="radio" name="category" value="bodyParts"> Body Parts</label>
                </div>
            </aside>
            <section id="items">
             
                </div>
            </section>
        </section>
    </main>
    <script src="shop.js"></script> <!-- Optional for JavaScript functionality -->
</body>
</html>
