<?php
include 'db_connect.php'; // Make sure this path is correct

// Check if $pdo is set
if (!$pdo) {
    die("Database connection failed.");
}

// SQL query to insert the new clan
$sql = "
    INSERT INTO clans (name, description, logo)
    VALUES (:name, :description, :logo)
";

$stmt = $pdo->prepare($sql);

// Data to insert
$data = [
    'name' => 'Awesome Clen!',
    'description' => 'We are awesome cleveland',
    'logo' => '/Clan_Logos/Clen.png'
];

// Execute the query
try {
    $stmt->execute($data);
    echo "Clan created successfully!";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
