<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$search_query = $_GET['search'] ?? '';
$show_online = isset($_GET['online']) ? (bool)$_GET['online'] : false;

try {
    // Prepare the SQL query based on search and online status
    $sql = "SELECT * FROM clans";
    $params = [];
    
    if ($search_query) {
        $sql .= " WHERE name LIKE ?";
        $params[] = "%$search_query%";
    }

    if ($show_online) {
        $sql .= $search_query ? " AND " : " WHERE ";
        $sql .= "online = 1";
    }

    $sql .= " ORDER BY members DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $clans = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clans - GPToria</title>
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="clans.css">
</head>
<body>
    <header class="top-bar">
        <div class="auth-links">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </header>
    <nav class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="play.php">Play</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="clans.php" class="active">Clans</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="forum.php">Forum</a></li>
            <li><a href="membership.php">Membership</a></li>
        </ul>
    </nav>
    <div class="container">
        <header class="clans-header">
            <h1>Top Clans</h1>
            <div class="search-bar">
                <form method="GET" action="clans.php">
                    <input type="text" name="search" placeholder="Search clans..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit">Search</button>
                    <label>
                        <input type="checkbox" name="online" <?php echo $show_online ? 'checked' : ''; ?>>
                        Show online only
                    </label>
                </form>
            </div>
        </header>
        <section class="clans-list">
            <?php if (empty($clans)): ?>
                <p>No clans found.</p>
            <?php else: ?>
                <?php foreach ($clans as $clan): ?>
                    <div class="clan-item">
                        <img src="<?php echo htmlspecialchars($clan['logo']); ?>" alt="Clan Logo" class="clan-logo">
                        <div class="clan-info">
                            <h2><?php echo htmlspecialchars($clan['name']); ?></h2>
                            <p><?php echo htmlspecialchars($clan['description']); ?></p>
                            <form method="GET" action="clan_details.php">
                                <input type="hidden" name="id" value="<?php echo $clan['id']; ?>">
                                <button type="submit" class="view-button">View Clan</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </div>
</body>
</html>
