<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$clan_id = $_GET['id'] ?? null;

if ($clan_id) {
    try {
        // Get clan details
        $stmt = $pdo->prepare("SELECT * FROM clans WHERE id = ?");
        $stmt->execute([$clan_id]);
        $clan = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$clan) {
            echo "Clan not found.";
            exit();
        }

        // Check if the user is a member of the clan
        $stmt = $pdo->prepare("SELECT * FROM clan_members WHERE user_id = ? AND clan_id = ?");
        $stmt->execute([$user_id, $clan_id]);
        $is_member = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
        exit();
    }
} else {
    echo "Invalid clan ID.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($clan['name']); ?> - GPToria</title>
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="clan_details.css">
</head>
<body>
    <nav class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="play.php">Play</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="clans.php">Clans</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="forum.php">Forum</a></li>
            <li><a href="membership.php">Membership</a></li>
        </ul>
    </nav>
    <div class="container">
        <header class="clan-header">
            <img src="<?php echo $clan['logo']; ?>" alt="Clan Logo" class="clan-logo">
            <h1><?php echo htmlspecialchars($clan['name']); ?></h1>
        </header>
        <section class="clan-description">
            <h2>Description</h2>
            <p><?php echo htmlspecialchars($clan['description']); ?></p>
        </section>
        <section class="clan-actions">
            <?php if ($is_member): ?>
                <form method="POST" action="leave_clan.php">
                    <input type="hidden" name="clan_id" value="<?php echo $clan_id; ?>">
                    <button type="submit" class="leave-button">Leave Clan</button>
                </form>
            <?php else: ?>
                <form method="POST" action="join_clan.php">
                    <input type="hidden" name="clan_id" value="<?php echo $clan_id; ?>">
                    <button type="submit" class="join-button">Join Clan</button>
                </form>
            <?php endif; ?>
        </section>
        <section class="clan-members">
            <h2>Clan Members</h2>
            <?php
            try {
                $stmt = $pdo->prepare("SELECT u.id, u.username, u.avatar FROM clan_members cm JOIN users u ON cm.user_id = u.id WHERE cm.clan_id = ?");
                $stmt->execute([$clan_id]);
                $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                echo "Database error: " . $e->getMessage();
            }
            ?>
            <div class="members-list">
                <?php foreach ($members as $member): ?>
                    <div class="member-item">
                        <img src="<?php echo htmlspecialchars($member['avatar']); ?>" alt="Member Avatar" class="member-avatar">
                        <p><?php echo htmlspecialchars($member['username']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </div>
</body>
</html>

