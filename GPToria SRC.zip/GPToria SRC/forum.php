<?php
session_start();
require 'db.php'; // Ensure this file connects to your database

// Fetch forum categories
$categories_query = $pdo->query("SELECT * FROM forum_categories");
$categories = $categories_query->fetchAll(PDO::FETCH_ASSOC);

// Fetch recent topics
$topics_query = $pdo->query("
    SELECT forum_topics.id, forum_topics.title, forum_topics.created_at, forum_categories.name AS category_name, users.username
    FROM forum_topics
    JOIN forum_categories ON forum_topics.category_id = forum_categories.id
    JOIN users ON forum_topics.created_by = users.id
    ORDER BY forum_topics.created_at DESC
");
$topics = $topics_query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link rel="stylesheet" href="forum.css"> <!-- Ensure this file styles your page -->
</head>
<body>
    <header>
        <div class="top-bar">
            <a href="index.php">Home</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <main>
        <h1>Forum</h1>
        <a href="create_thread.php" class="create-thread-button">Create New Thread</a>
        
        <section class="forum-categories">
            <h2>Categories</h2>
            <?php foreach ($categories as $category): ?>
                <div class="category">
                    <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                    <p><?php echo htmlspecialchars($category['description']); ?></p>
                </div>
            <?php endforeach; ?>
        </section>

        <section class="forum-threads">
            <h2>Recent Threads</h2>
            <?php foreach ($topics as $topic): ?>
                <div class="thread">
                    <h3><a href="thread.php?id=<?php echo $topic['id']; ?>"><?php echo htmlspecialchars($topic['title']); ?></a></h3>
                    <p>Category: <?php echo htmlspecialchars($topic['category_name']); ?></p>
                    <p>Created by: <?php echo htmlspecialchars($topic['username']); ?></p>
                    <p>Posted on: <?php echo htmlspecialchars($topic['created_at']); ?></p>
                </div>
            <?php endforeach; ?>
        </section>
    </main>
</body>
</html>
