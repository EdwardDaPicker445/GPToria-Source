<?php
session_start();
require 'db.php'; // Ensure this file connects to your database

// Check if the user is logged in and has admin privileges
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'fajay') {
    header("Location: index.php");
    exit();
}

// Handle category creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_category'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];

    // Insert new category into database
    $stmt = $pdo->prepare("INSERT INTO forum_categories (name, description) VALUES (?, ?)");
    $stmt->execute([$name, $description]);

    header("Location: manage_categories.php");
    exit();
}

// Fetch existing categories
$categories_query = $pdo->query("SELECT * FROM forum_categories");
$categories = $categories_query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="forum.css"> <!-- Ensure this file styles your page -->
</head>
<body>
    <header>
        <div class="top-bar">
            <a href="index.php">Home</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <main>
        <h1>Manage Categories</h1>
        <section class="category-form">
            <h2>Create New Category</h2>
            <form action="manage_categories.php" method="post">
                <label for="name">Category Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="4"></textarea>

                <button type="submit" name="create_category">Create Category</button>
            </form>
        </section>

        <section class="category-list">
            <h2>Existing Categories</h2>
            <?php foreach ($categories as $category): ?>
                <div class="category">
                    <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                    <p><?php echo htmlspecialchars($category['description']); ?></p>
                </div>
            <?php endforeach; ?>
        </section>
    </main>
</body>
</html>
