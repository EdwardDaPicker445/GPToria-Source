<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
$user_logged_in = isset($_SESSION['user_id']);
if ($user_logged_in) {
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT avatar FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<nav class="navbar">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="play.php">Play</a></li>
        <li><a href="shop.php">Shop</a></li>
        <li><a href="clans.php">Clans</a></li>
        <li><a href="users.php">Users</a></li>
        <li><a href="forum.php">Forum</a></li>
        <li><a href="membership.php">Membership</a></li>
        <?php if ($user_logged_in): ?>
            <li class="navbar-avatar">
                <a href="profile.php">
                    <img src="/avatars/<?php echo htmlspecialchars($user['avatar']); ?>" alt="User Avatar">
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>

