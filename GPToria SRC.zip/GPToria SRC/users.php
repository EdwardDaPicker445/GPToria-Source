<?php
session_start();
include 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$search_query = $_GET['search'] ?? '';
$show_online = isset($_GET['online']) ? (bool)$_GET['online'] : false;

try {
    // Prepare the SQL query based on search and online status
    $sql = "SELECT * FROM users";
    $params = [];
    
    if ($search_query) {
        $sql .= " WHERE username LIKE ?";
        $params[] = "%$search_query%";
    }

    if ($show_online) {
        $sql .= $search_query ? " AND " : " WHERE ";
        $sql .= "online = 1";
    }

    $sql .= " ORDER BY id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - GPToria</title>
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="users.css">
</head>
<body>
    <header class="top-bar">
        <div class="auth-links">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </header>
    <nav class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="play.php">Play</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="clans.php">Clans</a></li>
            <li><a href="users.php" class="active">Users</a></li>
            <li><a href="forum.php">Forum</a></li>
            <li><a href="membership.php">Membership</a></li>
        </ul>
    </nav>
    <div class="container">
        <header class="users-header">
            <h1>Users</h1>
            <div class="search-bar">
                <form method="GET" action="users.php">
                    <input type="text" name="search" placeholder="Search users..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit">Search</button>
                    <label>
                        <input type="checkbox" name="online" <?php echo $show_online ? 'checked' : ''; ?>>
                        Show online only
                    </label>
                </form>
            </div>
        </header>
        <section class="users-list">
            <?php if (empty($users)): ?>
                <p>No users found.</p>
            <?php else: ?>
                <?php foreach ($users as $user): ?>
                    <a href="profile.php?id=<?php echo htmlspecialchars($user['id']); ?>" class="user-link">
                        <div class="user-item">
                            <div class="user-status <?php echo $user['online'] ? 'online' : 'offline'; ?>"></div>
                            <div class="user-info">
                                <img src="/avatars/<?php echo htmlspecialchars($user['id']); ?>.png" alt="User Avatar" class="user-avatar">
                                <h2><?php echo htmlspecialchars($user['username']); ?></h2>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </div>
</body>
</html>
