<?php
session_start();
include 'db_connect.php';

// Fetch user details from the database
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username, avatar FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - GPToria</title>
    <link rel="stylesheet" href="navbar.css">
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    <header class="top-bar">
        <div class="auth-links">
            <a href="logout.php">Logout</a>
        </div>
    </header>
    <nav class="navbar">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="play.php">Play</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="clans.php">Clans</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="forum.php">Forum</a></li>
            <li><a href="membership.php">Membership</a></li>
        </ul>
    </nav>
    <?php include 'mini_navbar.php'; ?>
    <div class="container">
        <div class="profile-header">
            <img src="/avatars/<?php echo htmlspecialchars($user['avatar']); ?>" alt="User Avatar">
            <h1><?php echo htmlspecialchars($user['username']); ?></h1>
        </div>
    </div>
</body>
</html>
