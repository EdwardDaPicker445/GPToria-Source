<?php
require 'db.php'; // Include the database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $errorMessage = '';

    // Validate username
    if (strlen($username) < 3 || strlen($username) > 20) {
        $errorMessage .= 'Username must be between 3 and 20 characters long.<br>';
    }
    if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
        $errorMessage .= 'Username can only contain letters and numbers.<br>';
    }

    // Validate password
    if (strlen($password) < 3 || strlen($password) > 20) {
        $errorMessage .= 'Password must be between 3 and 20 characters long.<br>';
    }
    if (!preg_match('/^[a-zA-Z0-9]+$/', $password)) {
        $errorMessage .= 'Password can only contain letters and numbers.<br>';
    }

    if ($errorMessage) {
        echo "<p>$errorMessage</p>";
    } else {
        // Hash the password and insert into database
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        if ($stmt->execute([$username, $passwordHash])) {
            header("Location: login.php");
            exit();
        } else {
            echo "<p>Registration failed. Please try again.</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - GPToria</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap">
    <link rel="stylesheet" href="register.css">
    <script src="register.js" defer></script>
</head>
<body>
    <main>
        <h2>Register</h2>
        <form id="registerForm" method="post" action="register.php">
            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required>
            <button type="submit">Register</button>
            <p id="errorMessage"></p>
        </form>
    </main>
</body>
</html>
