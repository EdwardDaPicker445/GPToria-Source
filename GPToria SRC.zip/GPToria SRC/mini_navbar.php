<nav class="mini-navbar">
    <ul>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="settings.php">Settings</a></li>
        <li><a href="avatar.php">Avatar</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="download.php">Download</a></li>
        <li><a href="trades.php">Trades</a></li>
        <li><a href="sets.php">Sets</a></li>
        <li><a href="currency.php">Currency</a></li>
        <li><a href="blog.php">Blog</a></li>
    </ul>
</nav>
