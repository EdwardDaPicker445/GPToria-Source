document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registerForm');
    const errorMessage = document.getElementById('errorMessage');

    form.addEventListener('submit', (event) => {
        const username = form.username.value;
        const password = form.password.value;
        let valid = true;
        let message = '';

        // Check username length and special characters
        if (username.length < 3 || username.length > 20) {
            valid = false;
            message += 'Username must be between 3 and 20 characters long.<br>';
        }
        if (/[^a-zA-Z0-9]/.test(username)) {
            valid = false;
            message += 'Username can only contain letters and numbers.<br>';
        }

        // Check password length and special characters
        if (password.length < 3 || password.length > 20) {
            valid = false;
            message += 'Password must be between 3 and 20 characters long.<br>';
        }
        if (/[^a-zA-Z0-9]/.test(password)) {
            valid = false;
            message += 'Password can only contain letters and numbers.<br>';
        }

        if (!valid) {
            errorMessage.innerHTML = message;
            event.preventDefault(); // Prevent form submission
        }
    });
});
