<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPToria</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="navbar.css">
</head>
<body>
    <header class="top-bar">
        <div class="auth-links">
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        </div>
    </header>
    <nav class="navbar">
        <ul>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
        </ul>
    </nav>
    <div class="container">
        <header>
            <img src="/assets/brickgptbrickhill.png" alt="GPToria Logo" class="logo">
            <h1>BUILDING A COMMUNITY</h1>
            <p>Bringing people from all over the world together to create, collaborate, and play together built on values that put the player first. Join our community and help shape its future and your place in it!</p>
        </header>
        <main>
            <section class="rising-platform">
                <h2>A RISING PLATFORM</h2>
                <p>GPToria is a platform where creativity knows no bounds. Join us to explore endless possibilities and engage in exciting activities. Build your world, connect with others, and experience the future of online gaming.</p>
                <img src="/assets/dumbshop.png" alt="Rising Platform Image">
            </section>
        </main>
    </div>
</body>
</html>
