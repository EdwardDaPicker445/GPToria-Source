<?php
session_start();
require 'db.php'; // Ensure this file connects to your database

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $category_id = $_POST['category_id'];
    $user_id = $_SESSION['user_id'];

    // Insert new thread into database
    $stmt = $pdo->prepare("INSERT INTO forum_topics (title, category_id, created_by) VALUES (?, ?, ?)");
    $stmt->execute([$title, $category_id, $user_id]);

    header("Location: forum.php");
    exit();
}

// Fetch categories for dropdown
$categories_query = $pdo->query("SELECT * FROM forum_categories");
$categories = $categories_query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Thread</title>
    <link rel="stylesheet" href="forum.css"> <!-- Make sure this file styles your forum page -->
</head>
<body>
    <header>
        <div class="top-bar">
            <a href="index.php">Home</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php">Logout</a>
        </div>
        <div class="second-navbar">
            <a href="home.php">Home</a>
            <a href="settings.php">Settings</a>
            <a href="avatar.php">Avatar</a>
            <a href="profile.php">Profile</a>
            <a href="download.php">Download</a>
            <a href="trades.php">Trades</a>
            <a href="sets.php">Sets</a>
            <a href="currency.php">Currency</a>
            <a href="blog.php">Blog</a>
        </div>
    </header>

    <main>
        <h1>Create New Thread</h1>
        <form action="create_thread.php" method="post">
            <label for="title">Thread Title:</label>
            <input type="text" id="title" name="title" required>

            <label for="category">Category:</label>
            <select id="category" name="category_id" required>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Create Thread</button>
        </form>
    </main>
</body>
</html>
